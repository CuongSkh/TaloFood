import { useEffect, useMemo, useRef, useState } from 'react';
import products from '../data/products.json';
import MenuHero from '../components/MenuHero';
import MenuCategoryNav from '../components/MenuCategoryNav';
import MenuSection from '../components/MenuSection';
import ProductList from '../components/ProductList';

const categories = [
  { id: 'mon-moi', label: 'Món mới' },
  { id: 'combo', label: 'Combo' },
  { id: 'ga-ran', label: 'Gà rán' },
  { id: 'burger', label: 'Burger' },
  { id: 'thuc-an-nhe', label: 'Thức ăn nhẹ' },
  { id: 'thuc-uong', label: 'Thức uống' },
];

const normalizeText = (value) =>
  value.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();

const ProductPage = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [activeCategory, setActiveCategory] = useState(categories[0].id);
  const sectionRefs = useRef({});
  const isProgrammaticScroll = useRef(false);
  const scrollReleaseTimer = useRef(null);
  const isSearching = searchTerm.trim().length > 0;

  const groupedProducts = useMemo(
    () =>
      Object.fromEntries(
        categories.map((category) => [
          category.id,
          products.filter((product) => product.category === category.label),
        ]),
      ),
    [],
  );

  const searchResults = useMemo(() => {
    const keyword = normalizeText(searchTerm.trim());
    if (!keyword) return [];

    return products.filter((product) =>
      normalizeText(product.name).includes(keyword),
    );
  }, [searchTerm]);

  useEffect(() => {
    if (isSearching) return undefined;

    const headerHeight = 76;
    const categoryBarHeight = 68;
    const activationLine = headerHeight + categoryBarHeight + 24;

    const observer = new IntersectionObserver(
      (entries) => {
        if (isProgrammaticScroll.current) return;

        const visibleSections = entries
          .filter((entry) => entry.isIntersecting)
          .sort((a, b) => {
            const distanceA = Math.abs(a.boundingClientRect.top - activationLine);
            const distanceB = Math.abs(b.boundingClientRect.top - activationLine);
            return distanceA - distanceB;
          });

        if (visibleSections.length > 0) {
          setActiveCategory(visibleSections[0].target.id);
        }
      },
      {
        root: null,
        rootMargin: `-${activationLine}px 0px -55% 0px`,
        threshold: [0, 0.05, 0.15, 0.3, 0.5],
      },
    );

    categories.forEach(({ id }) => {
      const section = sectionRefs.current[id];
      if (section) observer.observe(section);
    });

    return () => observer.disconnect();
  }, [isSearching]);

  useEffect(
    () => () => {
      if (scrollReleaseTimer.current) {
        window.clearTimeout(scrollReleaseTimer.current);
      }
    },
    [],
  );

  const handleCategorySelect = (id) => {
    const targetSection = sectionRefs.current[id];
    if (!targetSection) return;

    setSearchTerm('');
    setActiveCategory(id);
    isProgrammaticScroll.current = true;

    const headerHeight = window.innerWidth <= 680 ? 68 : 76;
    const categoryBarHeight = window.innerWidth <= 680 ? 58 : 68;
    const offset = headerHeight + categoryBarHeight + 16;
    const targetTop = targetSection.getBoundingClientRect().top + window.scrollY - offset;

    window.scrollTo({
      top: Math.max(0, targetTop),
      behavior: 'smooth',
    });

    if (scrollReleaseTimer.current) {
      window.clearTimeout(scrollReleaseTimer.current);
    }

    scrollReleaseTimer.current = window.setTimeout(() => {
      isProgrammaticScroll.current = false;
    }, 700);
  };

  return (
    <main className="menu-page">
      <MenuHero />
      <MenuCategoryNav
        categories={categories}
        activeId={activeCategory}
        onSelect={handleCategorySelect}
      />

      <div className="container menu-page__content">
        <div className="menu-search">
          <label htmlFor="menu-search-input" className="sr-only">
            Tìm món ăn
          </label>
          <span aria-hidden="true">⌕</span>
          <input
            id="menu-search-input"
            type="search"
            placeholder="Tìm món ăn bạn yêu thích..."
            value={searchTerm}
            onChange={(event) => setSearchTerm(event.target.value)}
          />
        </div>

        {isSearching ? (
          <section className="menu-search-results" aria-live="polite">
            <div className="menu-section__heading">
              <h2>Kết quả tìm kiếm</h2>
              <span>{searchResults.length} món phù hợp</span>
            </div>
            {searchResults.length > 0 ? (
              <ProductList products={searchResults} />
            ) : (
              <div className="menu-empty-state">
                <strong>Không tìm thấy món ăn phù hợp.</strong>
                <p>Hãy thử tìm bằng tên món khác.</p>
              </div>
            )}
          </section>
        ) : (
          categories.map((category) => (
            <MenuSection
              key={category.id}
              category={category}
              products={groupedProducts[category.id]}
              sectionRef={(element) => {
                sectionRefs.current[category.id] = element;
              }}
            />
          ))
        )}
      </div>
    </main>
  );
};

export default ProductPage;
